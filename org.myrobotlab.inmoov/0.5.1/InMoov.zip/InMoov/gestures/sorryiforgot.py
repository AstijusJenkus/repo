# -- coding: utf-8 --

def sorryiforgot():
  x = (random.randint(1, 2))
  if x == 1:
    i01.mouth.speak("that's alright")
	#i01.mouth.speak(u"все в порядке")
  if x == 2:
    i01.mouth.speak("you forget all the time")
	#i01.mouth.speak(u"Вы всё время забываете")
