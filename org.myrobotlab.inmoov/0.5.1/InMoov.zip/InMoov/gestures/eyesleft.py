def eyesleft():
  i01.head.eyeX.moveTo(180)

