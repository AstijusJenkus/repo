def cyclegesture1():
  i01.startedGesture()
  welcome()
  sleep(1)
  relax()
  servos()
  i01.finishedGesture()