# -- coding: utf-8 --
# #############################################################################
#                           YOUR INMOOV CUSTOM
# Here you can add your own commands to play and test with inmoov
# If you udpate the whole script, don't worry, those commands are safe
# ##############################################################################


#sample
# play a neopixel animation while the robot speaking
#PlayNeopixelAnimation("Flash Random", 255, 255, 255, 1)
# talk something
#talkBlocking("she's a replicant, isn't she?")
# stop neopixel
#StopNeopixelAnimation()

