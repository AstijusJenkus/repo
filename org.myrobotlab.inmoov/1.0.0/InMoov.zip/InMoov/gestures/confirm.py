def confirm():
  i01.mouth.speakBlocking("Would you like to save this gesture")