def checkgesture(name):
  i01.checkGesture(name)