def preview():
    i01.previewGesture()