def copy():
    i01.copyGestures()