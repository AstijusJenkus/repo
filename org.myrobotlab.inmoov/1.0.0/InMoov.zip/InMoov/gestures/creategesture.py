def creategesture(file_name):
  i01.createGestureScript(file_name)