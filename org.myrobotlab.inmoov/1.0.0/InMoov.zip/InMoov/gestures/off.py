def off():
    i01.copyGestures()