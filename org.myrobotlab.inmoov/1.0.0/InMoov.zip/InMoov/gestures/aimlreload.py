def aimlreload():
  i01.compileAiml()