def disable():
  i01.disable()
