def openrighthand():
  i01.moveHand("right",0,0,0,0,0)

