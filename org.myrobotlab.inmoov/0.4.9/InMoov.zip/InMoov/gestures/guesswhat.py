# -- coding: utf-8 --

def guesswhat():
  i01.mouth.speak("I'm not really a human man")
  #i01.mouth.speak(u"Я на самом деле не человек")
  i01.mouth.speak("but I use Old spice body wash and deodorant together")
  # i01.mouth.speak(u"Но я использую Old spice и дезодорант для тела")
  i01.mouth.speak("and now I'm really cool")
  #i01.mouth.speak(u"И теперь я действительно крутой")
  


