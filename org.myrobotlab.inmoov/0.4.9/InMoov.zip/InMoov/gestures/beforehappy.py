def beforehappy():
  i01.setHandSpeed("left", 1.0, 1.0, 1.0, 1.0, 1.0, 1.0)
  i01.setHandSpeed("right", 1.0, 1.0, 1.0, 1.0, 1.0, 1.0)
  i01.setArmSpeed("right", 0.85, 0.85, 0.85, 1.0)
  i01.setArmSpeed("left", 1.0, 1.0, 1.0, 1.0)
  i01.setHeadSpeed(0.65, 0.65)
  i01.moveHead(84,88)
  i01.moveArm("left",5,82,36,11)
  i01.moveArm("right",74,112,61,29)
  i01.moveHand("left",0,88,135,94,96,90)
  i01.moveHand("right",81,79,118,47,0,90)

