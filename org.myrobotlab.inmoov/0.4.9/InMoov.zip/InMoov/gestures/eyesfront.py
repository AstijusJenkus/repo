def eyesfront():
  i01.head.eyeX.moveTo(85)
  i01.head.eyeY.moveTo(85)

