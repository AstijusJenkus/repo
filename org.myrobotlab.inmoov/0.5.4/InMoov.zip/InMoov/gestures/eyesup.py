def eyesup():
  i01.startedGesture()
  i01.head.eyeY.moveTo(0)
  sleep(1)
  i01.finishedGesture()

