def closerighthand():
  i01.moveHand("right",180,180,180,180,180)


