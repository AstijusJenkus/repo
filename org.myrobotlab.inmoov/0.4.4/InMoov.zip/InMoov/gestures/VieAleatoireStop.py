def VieAleatoireStop():
  MoveRandomTimer.stopClock()

  