# -- coding: utf-8 --

def iknow():
  x = (random.randint(1, 3))
  if x == 1:
    i01.mouth.speak("yes, me too")
	#i01.mouth.speak(u"Да, я тоже")
  if x == 2:
    i01.mouth.speak("I do too")
	#i01.mouth.speak(u"я тоже")
  if x == 3:
    i01.mouth.speak("sorry about that")
	#i01.mouth.speak(u"Извини за это")
