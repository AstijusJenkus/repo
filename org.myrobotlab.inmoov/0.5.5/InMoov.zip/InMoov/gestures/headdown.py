def headdown():
  i01.head.neck.moveTo(0)

