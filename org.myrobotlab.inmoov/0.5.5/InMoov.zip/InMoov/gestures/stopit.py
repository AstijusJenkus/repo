# -- coding: utf-8 --

def stopit():
  lookinmiddle()
  sleep(1)
  relax()
  i01.mouth.speak("yes")
  #i01.mouth.speak(u"да")
  if (data == "pause"):# пауза
    i01.mouth.speak("yes")
	#i01.mouth.speak(u"да")

