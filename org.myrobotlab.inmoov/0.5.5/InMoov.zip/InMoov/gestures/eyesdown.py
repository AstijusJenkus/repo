def eyesdown():
  i01.startedGesture()
  i01.head.eyeY.moveTo(180)
  sleep(1)
  i01.finishedGesture()

