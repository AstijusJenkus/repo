def stopfacerecognizer():
  #i01.opencv.stopCapture()
  i01.opencv.removeFilter("PyramidDown")
  i01.opencv.removeFilter("FaceRecognizer")
