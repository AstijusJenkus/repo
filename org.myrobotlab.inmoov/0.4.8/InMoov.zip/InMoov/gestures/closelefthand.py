def closelefthand():
  i01.moveHand("left",180,180,180,180,180)


