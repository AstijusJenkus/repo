def eyesdown():
  i01.head.eyeY.moveTo(180)

