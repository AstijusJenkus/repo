Inmoov OS  
Powered by Myrobotlab  

[DOCUMENTATION]

https://github.com/MyRobotLab/inmoov/wiki/HOWTO---USING-SCRIPT--FINGERSTARTER  
https://github.com/MyRobotLab/inmoov/wiki/

topic : http://myrobotlab.org/content/inmoov-script-merge-them-all

bugs : https://github.com/MyRobotLab/inmoov/issues
