def offkinect():
  i01.leftArm.shoulder.map(0,180,0,180)
  i01.rightArm.shoulder.map(0,180,0,180)
  i01.copyGesture(False)
  rest()


