def eyesfront():
  i01.startedGesture()
  i01.head.eyeX.moveTo(90)
  i01.head.eyeY.moveTo(90)
  i01.finishedGesture()

