Inmoov OS  
testing  

[**DOCUMENTATION**]  
  
https://github.com/MyRobotLab/inmoov/wiki/HOWTO---USING-SCRIPT--FINGERSTARTER  
  
if you find bugs : https://github.com/MyRobotLab/inmoov/issues  
  
[**CHANGELOG**]  
0.4.0  
- inmoov knowledge - beta  
0.3.9  
- openni skeleton capture  
0.3.6  
- utf8 friendly inside logs & webgui  
- linux compatibility fixed  
