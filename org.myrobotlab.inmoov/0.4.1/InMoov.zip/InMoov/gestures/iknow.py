def iknow():
  x = (random.randint(1, 3))
  if x == 1:
    i01.mouth.speak("yes, me too")
  if x == 2:
    i01.mouth.speak("I do too")
  if x == 3:
    i01.mouth.speak("sorry about that")
