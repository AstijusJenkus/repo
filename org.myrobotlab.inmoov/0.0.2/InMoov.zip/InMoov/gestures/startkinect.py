def startkinect():
  i01.leftArm.shoulder.map(0,180,-25,105)
  i01.rightArm.shoulder.map(0,180,-30,100)
  i01.copyGesture(True)


