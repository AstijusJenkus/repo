def rockpaperscissors():
  fullspeed()
  i01.mouth.speak("lets play first to 3 points win")
  sleep(4)
  rockpaperscissors2(data)

