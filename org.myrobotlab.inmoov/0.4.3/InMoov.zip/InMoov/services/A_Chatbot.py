# ##############################################################################
#                 CHATBOT PROGRAM.AB SERVICE
# ##############################################################################

# ##############################################################################
#               PERSONNAL PARAMETERS
# ##############################################################################  
  
#read current service part config based on file name
ThisServicePart=RuningFolder+'config/service_'+os.path.basename(inspect.stack()[0][1]).replace('.py','')

###############################################################################
#                 webgui sync
getInmoovFrParameter('chatbot',ThisServicePart+'.config')
###############################################################################

CheckFileExist(ThisServicePart)
ThisServicePartConfig = ConfigParser.ConfigParser()
ThisServicePartConfig.read(ThisServicePart+'.config')
isChatbotActivated=0

isChatbotActivated=ThisServicePartConfig.getboolean('MAIN', 'isChatbotActivated')

# ##############################################################################
# MRL SERVICE CALL
# ##############################################################################

# We check if MRL was cleanly closed
mrlWasNotCleanlyShutdownedFile="mrlWasNotCleanlyShutdowned"
if os.path.isfile(mrlWasNotCleanlyShutdownedFile):
  if (os.path.isdir(RuningFolder+'chatbot/bots/'+MyLanguage+'/aiml')):
    errorSpokenFunc('lang_BadShutdown')
    try:
      shutil.rmtree(RuningFolder+'chatbot/bots/'+MyLanguage+'/aimlif')
    except: 
      pass  
open("mrlWasNotCleanlyShutdowned", 'a').close()

Runtime.createAndStart("htmlFilter", "HtmlFilter")
chatBot=Runtime.start("chatBot", "ProgramAB")
if isChatbotActivated:
  chatBot.repetition_count(10)
  chatBot.setPath(RuningFolder+"chatbot/")
  talkEvent(lang_chatbotLoading)
  chatBot.startSession("default",MyLanguage)
  talkEvent(lang_chatbotActivated)
  chatBot.addTextListener(htmlFilter)
  htmlFilter.addListener("publishText", python.name, "talk")
  chatBot.setPredicate("default","topic","default")
  chatBot.setPredicate("default","questionfirstinit","")
  chatBot.setPredicate("default","tmpname","")
  chatBot.setPredicate("default","null","")
  chatBot.savePredicates()
else:
  errorSpokenFunc('lang_ChatbotError')

def writeAIML():  
  chatBot.writeAIMLIF()
  
# wikidata helper
WikiFile="WIKIDATA_propEN.txt"
if MyLanguage=="fr":WikiFile="WIKIDATA_propFR.txt"