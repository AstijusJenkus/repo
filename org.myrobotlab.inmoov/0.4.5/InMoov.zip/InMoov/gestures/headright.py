def headright():
  i01.head.rothead.moveTo(0)

