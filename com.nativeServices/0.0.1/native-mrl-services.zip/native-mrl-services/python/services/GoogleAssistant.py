import logging
from mrlpy.mservice import MService
from google.assistant.__main__ import main
from multiprocessing import Process

#This is an example service. To create it, you MUST have an MRL instance running and mrlpy configured to connect
#To create, either run python exampleService.py or, in MRL, create a proxy and call proxy.startNativeService() with the location
#of this script as the argument
class GoogleAssistant(MService):
	log = logging.getLogger(__name__)
	assistantProcess = None
	#Basic constructor of service, should have this signature but not required
	def __init__(self, name=""):
		
		#Overrides default proxy class of PythonProxy, allowing a custom proxy to be used instead
		super(GoogleAssistant, self).setProxyClass(type(self).__name__)
		#REALLY REALLY REALLY IMPORTANT TO CALL THIS, otherwise service is not registered, name not allocated, everything blows up
		super(GoogleAssistant, self).__init__(name) #If name is empty string, then it is taken from the first command-line argument.  If there is no such argument, then the name is auto-generated
		del sys.argv[1]
	#Normal method declarations. MService handles messaging and invocation of methods, so nothing special is needed
	def start(self):
		assistantProcess = Process(target=main)
		assistantProcess.daemon = True;
		assistantProcess.start()

	def stop(self):
		if assistantProcess is not None:
			assistantProcess.terminate()


#This allows the service to be created when calling on the command line
if __name__ == "__main__":
	GoogleAssistant()
